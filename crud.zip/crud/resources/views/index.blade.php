@extends('template')

@section('content')
    <div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>CRUD</h2>
            </div>
            <div hidden="" class="float-right">
                <a class="btn btn-success" href="{{ route('datas.create') }}"> Transfer Barang</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('succes'))
    <div class="alert alert-success">
        <p>{{ $message }}</p>
    </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th width="20px" class="text-center">No</th>
            <th>Jenis</th>
            <th width="280px"class="text-center">Nama Branch</th>
            <th width="280px"class="text-center">Kode Unik</th>
            
            
        </tr>
        @foreach ($datas as $siswa)
        <tr>
            <td class="text-center">{{ ++$i }}</td>
            <td>{{ $siswa->jenis }}</td>
            <td>{{ $siswa->kodebranch }}</td>
            <td>{{ $siswa->kodeunik }}</td>
            
            <td><a class="btn btn-success" href="{{ route('generate',$siswa->id) }}"> Generate</a></td>
            
        </tr>
        @endforeach
    </table>

    {!! $datas->links() !!}

@endsection
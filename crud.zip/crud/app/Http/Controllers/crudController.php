<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;
use Illuminate\Support\Facades\Hash;
use SimpleSoftwareIO\QrCode\Facades\QrCode;


class crudController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = Barang::latest()->paginate(5);
        return view ('index',compact('datas'))->with('i', (request()->input('page',1)-1)*5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    public function generate($id)
    {
        $datas = Barang::findOrFail($id);
        $qrcode = QrCode::size(400)->generate($datas->qr_code);
        return view('qrcode',compact('qrcode'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'jenis' => 'required',
            'kodebranch' => 'required',
            'kodeunik' => 'required',
        ]);
        Barang::create($request->all());
        return redirect()->route('datas.index')->with('Success', 'Data Berhasil ditransfer');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Barang $datas)
    {
        return view('show', compact('datas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $datas = Barang::findOrFail($id);
        return view('edit', compact('datas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'jenis'=> 'required',
            'kodebranch' => 'required',
            'kodeunik' => 'required',
        ]);

        $datas = Barang::findOrFail($id);
        $datas->update([
            'jenis' => $request->jenis,
            'kodebranch' => $request->kodebranch,
            'kodeunik' => $request->kodeunik,

        ]);

        if ($datas) {
            return redirect()
                ->route('datas.index')
                ->with([
                    'success' => 'Data has been updated successfully'
                ]);
        } else {
            return redirect()
                ->back()
                ->withInput()
                ->with([
                    'error' => 'Some problem has occured, please try again'
                ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $datas = Barang::findOrFail($id);
        $datas->delete();

        if ($datas) {
            return redirect()
                ->route('datas.index')
                ->with([
                    'success' => 'Data has been deleted successfully'
                ]);
        } else {
            return redirect()
                ->route('datas.index')
                ->with([
                    'error' => 'Some problem has occurred, please try again'
                ]);
    }
}
}

@extends('template')

@section('content')
<div class="row mt-5 mb-5">
    <div class="col-lg-12 margin-tb">
        <div class="float-left">
            <h2>Input Transfer Barang</h2>
        </div>
        <div class="float-right">
            <a class="btn btn-secondary" href="{{ route('datas.index') }}"> Kembali</a>
        </div>
    </div>
</div>

@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> Input gagal.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('datas.store') }}" method="POST">
    @csrf

     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Jenis Transfer:</strong>
                <select name="jenis" id="">
                  <option value="SW">Switch</option>
                  <option value="SV">Server</option>
                  <option value="RT">Router</option>   
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nama Branch:</strong>
                <select name="kodebranch" id="">
                  <option value="JKT">Jakarta</option>
                  <option value="BKS">Bekasi</option>
                  <option value="BGR">Bogor</option>   
                  <option value="BDG">Bandung</option>
                </select>
            </div>
        </div>
        <div hidden="" class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Kode unik:</strong>
                <?php 
                $a = 1;
                $a++;
                $b = date("m");
                $c = date("y");?>
                <input type="text" name="kodeunik" class="form-control" value="<?php echo $b.$c.'0'.$a ?>">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>

</form>
@endsection
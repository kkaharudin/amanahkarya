<!DOCTYPE html>
<html>
<head>
    <title>CRUD - Test PT. Amanah Karya</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html><?php /**PATH C:\Users\Bernadi_Khanif\crud\resources\views/template.blade.php ENDPATH**/ ?>
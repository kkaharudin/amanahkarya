

<?php $__env->startSection('content'); ?>
    <div class="row mt-5 mb-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-left">
                <h2>CRUD</h2>
            </div>
            <div hidden="" class="float-right">
                <a class="btn btn-success" href="<?php echo e(route('datas.create')); ?>"> Transfer Barang</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('succes')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th width="20px" class="text-center">No</th>
            <th>Jenis</th>
            <th width="280px"class="text-center">Nama Branch</th>
            <th width="280px"class="text-center">Kode Unik</th>
            
            
        </tr>
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e(++$i); ?></td>
            <td><?php echo e($siswa->jenis); ?></td>
            <td><?php echo e($siswa->kodebranch); ?></td>
            <td><?php echo e($siswa->kodeunik); ?></td>
            
            <td><a class="btn btn-success" href="<?php echo e(route('generate',$siswa->id)); ?>"> Generate</a></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $datas->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bernadi_Khanif\crud\resources\views/index.blade.php ENDPATH**/ ?>